# GitHub Pages PDF 下载模拟

- `resume.pdf` 是伪装的跳转链接（实际上是 HTML 文件）
- `real-resume.pdf` 是你真正的 PDF 文件
- 上传到 GitHub Pages 后，访问 `.pdf` 链接即可强制下载 PDF
